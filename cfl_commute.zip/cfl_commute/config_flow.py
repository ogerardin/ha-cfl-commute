"""Config flow for CFL Commute."""

import logging
from typing import Any, Optional
import voluptuous as vol
from homeassistant import config_entries
from homeassistant.core import callback
from homeassistant.data_entry_flow import FlowResult
from homeassistant.helpers import selector
from .api import CFLCommuteClient
from .const import (
    CONF_ADD_RETURN_JOURNEY,
    CONF_API_KEY,
    CONF_ORIGIN,
    CONF_DESTINATION,
    CONF_COMMUTE_NAME,
    CONF_TIME_WINDOW,
    CONF_NUM_TRAINS,
    CONF_MINOR_THRESHOLD,
    CONF_MAJOR_THRESHOLD,
    CONF_SEVERE_THRESHOLD,
    CONF_NIGHT_UPDATES,
    CONF_DEPARTED_TRAIN_GRACE_PERIOD,
    DEFAULT_TIME_WINDOW,
    DEFAULT_NUM_TRAINS,
    DEFAULT_MINOR_THRESHOLD,
    DEFAULT_MAJOR_THRESHOLD,
    DEFAULT_SEVERE_THRESHOLD,
    DEFAULT_NIGHT_UPDATES,
    DEFAULT_DEPARTED_TRAIN_GRACE_PERIOD,
    MIN_GRACE_PERIOD,
    MAX_GRACE_PERIOD,
    DOMAIN,
)

_LOGGER = logging.getLogger(__name__)

CONFIG_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_API_KEY): str,
    }
)


class CannotConnect(Exception):
    """Error to indicate we cannot connect to the API."""


class CFLCommuteConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle a config flow for CFL Commute."""

    VERSION = 1

    def __init__(self):
        """Initialize the config flow."""
        self._api_key: str = ""
        self._origin_station: dict = {}
        self._destination_station: dict = {}
        self._client: Optional[CFLCommuteClient] = None
        self._all_stations: list[selector.SelectOptionDict] = []
        self._commute_name: str | None = None
        self._time_window: int | None = None
        self._num_trains: int | None = None
        self._minor_threshold: int | None = None
        self._major_threshold: int | None = None
        self._severe_threshold: int | None = None
        self._night_updates: bool | None = None
        self._departed_train_grace_period: int | None = None

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Handle the initial step."""
        errors: dict[str, str] = {}

        existing_entries = self._async_current_entries()
        if existing_entries:
            first_entry = existing_entries[0]
            self._api_key = first_entry.data.get(CONF_API_KEY, "")
            if self._api_key:
                self._client = CFLCommuteClient(self._api_key)
                return await self.async_step_origin()

        if user_input is not None:
            self._api_key = user_input[CONF_API_KEY]
            self._client = CFLCommuteClient(self._api_key)
            return await self.async_step_origin()

        return self.async_show_form(
            step_id="user",
            data_schema=CONFIG_SCHEMA,
            errors=errors,
            description_placeholders={
                "instructions": "Get your free API key from opendata-api@atp.etat.lu"
            },
        )

    async def _fetch_all_stations(self) -> list[selector.SelectOptionDict]:
        """Fetch all stations from API."""
        if not self._client:
            raise CannotConnect("API client not initialized")
        try:
            stations = await self._client.search_stations("")
            return sorted(
                [selector.SelectOptionDict(value=s.id, label=s.name) for s in stations],
                key=lambda x: x["label"],
            )
        except Exception as e:
            _LOGGER.error(f"Failed to fetch stations: {e}")
            raise CannotConnect(f"Failed to fetch stations: {e}")

    def _get_station_schema(
        self,
        stations: list[selector.SelectOptionDict],
    ) -> vol.Schema:
        """Build schema with station dropdown."""
        station_selector = selector.SelectSelector(
            selector.SelectSelectorConfig(
                options=stations,
                mode=selector.SelectSelectorMode.DROPDOWN,
            )
        )
        return vol.Schema(
            {
                vol.Required("station"): station_selector,
            }
        )

    async def async_step_origin(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Handle origin station selection."""
        errors: dict[str, str] = {}

        if not self._all_stations:
            try:
                self._all_stations = await self._fetch_all_stations()
            except CannotConnect as e:
                return self.async_abort(reason=str(e))

        if user_input is not None:
            station_id = user_input.get("station")
            if station_id:
                station_name = next(
                    (
                        s["label"]
                        for s in self._all_stations
                        if s["value"] == station_id
                    ),
                    station_id,
                )
                self._origin_station = {"id": station_id, "name": station_name}
                return await self.async_step_destination()

        return self.async_show_form(
            step_id="origin",
            data_schema=self._get_station_schema(self._all_stations),
            errors=errors,
            description_placeholders={"step": "origin"},
        )

    async def async_step_destination(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Handle destination station selection."""
        errors: dict[str, str] = {}

        if user_input is not None:
            station_id = user_input.get("station")
            if station_id:
                station_name = next(
                    (
                        s["label"]
                        for s in self._all_stations
                        if s["value"] == station_id
                    ),
                    station_id,
                )
                self._destination_station = {"id": station_id, "name": station_name}
                return await self.async_step_settings()

        return self.async_show_form(
            step_id="destination",
            data_schema=self._get_station_schema(self._all_stations),
            errors=errors,
            description_placeholders={"step": "destination"},
        )

    async def async_step_settings(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Handle settings configuration."""
        errors: dict[str, str] = {}

        if user_input is not None:
            self._commute_name = user_input.get(
                CONF_COMMUTE_NAME,
                f"{self._origin_station.get('name', 'Origin')} → {self._destination_station.get('name', 'Destination')}",
            )
            self._time_window = user_input.get(CONF_TIME_WINDOW, DEFAULT_TIME_WINDOW)
            self._num_trains = user_input.get(CONF_NUM_TRAINS, DEFAULT_NUM_TRAINS)
            self._minor_threshold = user_input.get(
                CONF_MINOR_THRESHOLD, DEFAULT_MINOR_THRESHOLD
            )
            self._major_threshold = user_input.get(
                CONF_MAJOR_THRESHOLD, DEFAULT_MAJOR_THRESHOLD
            )
            self._severe_threshold = user_input.get(
                CONF_SEVERE_THRESHOLD, DEFAULT_SEVERE_THRESHOLD
            )
            self._night_updates = user_input.get(
                CONF_NIGHT_UPDATES, DEFAULT_NIGHT_UPDATES
            )
            self._departed_train_grace_period = user_input.get(
                CONF_DEPARTED_TRAIN_GRACE_PERIOD, DEFAULT_DEPARTED_TRAIN_GRACE_PERIOD
            )

            return await self.async_step_return_journey()

        default_name = f"{self._origin_station.get('name', 'Origin')} → {self._destination_station.get('name', 'Destination')}"

        return self.async_show_form(
            step_id="settings",
            data_schema=vol.Schema(
                {
                    vol.Required(
                        CONF_COMMUTE_NAME,
                        default=default_name,
                        description="Commute Name",
                    ): str,
                    vol.Required(
                        CONF_TIME_WINDOW,
                        default=DEFAULT_TIME_WINDOW,
                        description="Time Window (minutes)",
                    ): vol.All(vol.Coerce(int), vol.Range(min=0, max=180)),
                    vol.Required(
                        CONF_NUM_TRAINS,
                        default=DEFAULT_NUM_TRAINS,
                        description="Number of Trains",
                    ): vol.All(vol.Coerce(int), vol.Range(min=1, max=10)),
                    vol.Required(
                        CONF_MINOR_THRESHOLD,
                        default=DEFAULT_MINOR_THRESHOLD,
                        description="Minor Delays Threshold (min)",
                    ): vol.All(vol.Coerce(int), vol.Range(min=1, max=60)),
                    vol.Required(
                        CONF_MAJOR_THRESHOLD,
                        default=DEFAULT_MAJOR_THRESHOLD,
                        description="Major Delays Threshold (min)",
                    ): vol.All(vol.Coerce(int), vol.Range(min=1, max=60)),
                    vol.Required(
                        CONF_SEVERE_THRESHOLD,
                        default=DEFAULT_SEVERE_THRESHOLD,
                        description="Severe Disruption Threshold (min)",
                    ): vol.All(vol.Coerce(int), vol.Range(min=1, max=60)),
                    vol.Required(
                        CONF_DEPARTED_TRAIN_GRACE_PERIOD,
                        default=DEFAULT_DEPARTED_TRAIN_GRACE_PERIOD,
                        description="Departed Train Grace Period (min)",
                    ): vol.All(
                        vol.Coerce(int),
                        vol.Range(min=MIN_GRACE_PERIOD, max=MAX_GRACE_PERIOD),
                    ),
                    vol.Required(
                        CONF_NIGHT_UPDATES,
                        default=DEFAULT_NIGHT_UPDATES,
                        description="Enable Night Updates",
                    ): bool,
                }
            ),
            errors=errors,
        )

    async def async_step_return_journey(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Offer to set up the reverse commute if it doesn't already exist."""
        reverse_unique_id = (
            f"{self._destination_station['id']}_{self._origin_station['id']}"
        )
        reverse_exists = any(
            entry.unique_id == reverse_unique_id
            for entry in self._async_current_entries()
        )

        if reverse_exists:
            return self._create_entry()

        if user_input is not None:
            if user_input.get(CONF_ADD_RETURN_JOURNEY, False):
                self.hass.async_create_task(
                    self.hass.config_entries.flow.async_init(
                        DOMAIN,
                        context={"source": config_entries.SOURCE_IMPORT},
                        data={
                            CONF_API_KEY: self._api_key,
                            CONF_ORIGIN: self._destination_station,
                            CONF_DESTINATION: self._origin_station,
                            CONF_COMMUTE_NAME: f"{self._destination_station.get('name', 'Destination')} → {self._origin_station.get('name', 'Origin')}",
                            CONF_TIME_WINDOW: self._time_window,
                            CONF_NUM_TRAINS: self._num_trains,
                            CONF_MINOR_THRESHOLD: self._minor_threshold,
                            CONF_MAJOR_THRESHOLD: self._major_threshold,
                            CONF_SEVERE_THRESHOLD: self._severe_threshold,
                            CONF_NIGHT_UPDATES: self._night_updates,
                            CONF_DEPARTED_TRAIN_GRACE_PERIOD: self._departed_train_grace_period,
                        },
                    )
                )
            return self._create_entry()

        return self.async_show_form(
            step_id="return_journey",
            data_schema=vol.Schema(
                {
                    vol.Required(
                        CONF_ADD_RETURN_JOURNEY, default=True
                    ): selector.BooleanSelector(),
                }
            ),
            description_placeholders={
                "origin": self._origin_station.get("name", "Origin"),
                "destination": self._destination_station.get("name", "Destination"),
            },
        )

    async def async_step_import(self, user_input: dict[str, Any]) -> FlowResult:
        """Handle automatic creation of a return journey config entry."""
        await self.async_set_unique_id(
            f"{user_input[CONF_ORIGIN]['id']}_{user_input[CONF_DESTINATION]['id']}"
        )
        self._abort_if_unique_id_configured()
        return self.async_create_entry(
            title=user_input[CONF_COMMUTE_NAME],
            data=user_input,
        )

    def _create_entry(self) -> FlowResult:
        """Create the config entry using stored instance variables."""
        return self.async_create_entry(
            title=self._commute_name or "",
            data={
                CONF_API_KEY: self._api_key,
                CONF_ORIGIN: self._origin_station,
                CONF_DESTINATION: self._destination_station,
                CONF_COMMUTE_NAME: self._commute_name,
                CONF_TIME_WINDOW: self._time_window,
                CONF_NUM_TRAINS: self._num_trains,
                CONF_MINOR_THRESHOLD: self._minor_threshold,
                CONF_MAJOR_THRESHOLD: self._major_threshold,
                CONF_SEVERE_THRESHOLD: self._severe_threshold,
                CONF_NIGHT_UPDATES: self._night_updates,
                CONF_DEPARTED_TRAIN_GRACE_PERIOD: self._departed_train_grace_period,
            },
        )

    @staticmethod
    @callback
    def async_get_options_flow(
        config_entry: config_entries.ConfigEntry,
    ) -> config_entries.OptionsFlow:
        """Get options flow."""
        return CFLCommuteOptionsFlow()


class CFLCommuteOptionsFlow(config_entries.OptionsFlow):
    """Options flow for CFL Commute."""

    async def async_step_init(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Handle options step."""
        errors: dict[str, str] = {}

        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)

        config_entry = self.hass.config_entries.async_get_entry(self.handler)
        if config_entry is None:
            return self.async_abort(reason="Config entry not found")

        current_options = (
            dict(config_entry.options)
            if config_entry.options
            else dict(config_entry.data)
        )

        data_schema = vol.Schema(
            {
                vol.Optional(CONF_COMMUTE_NAME): str,
                vol.Required(
                    CONF_TIME_WINDOW,
                    default=current_options.get(CONF_TIME_WINDOW, DEFAULT_TIME_WINDOW),
                    description="Time Window (minutes)",
                ): vol.All(vol.Coerce(int), vol.Range(min=0, max=180)),
                vol.Required(
                    CONF_NUM_TRAINS,
                    default=current_options.get(CONF_NUM_TRAINS, DEFAULT_NUM_TRAINS),
                    description="Number of Trains",
                ): vol.All(vol.Coerce(int), vol.Range(min=1, max=10)),
                vol.Required(
                    CONF_MINOR_THRESHOLD,
                    default=current_options.get(
                        CONF_MINOR_THRESHOLD, DEFAULT_MINOR_THRESHOLD
                    ),
                    description="Minor Delays Threshold (min)",
                ): vol.All(vol.Coerce(int), vol.Range(min=1, max=60)),
                vol.Required(
                    CONF_MAJOR_THRESHOLD,
                    default=current_options.get(
                        CONF_MAJOR_THRESHOLD, DEFAULT_MAJOR_THRESHOLD
                    ),
                    description="Major Delays Threshold (min)",
                ): vol.All(vol.Coerce(int), vol.Range(min=1, max=60)),
                vol.Required(
                    CONF_SEVERE_THRESHOLD,
                    default=current_options.get(
                        CONF_SEVERE_THRESHOLD, DEFAULT_SEVERE_THRESHOLD
                    ),
                    description="Severe Disruption Threshold (min)",
                ): vol.All(vol.Coerce(int), vol.Range(min=1, max=60)),
                vol.Required(
                    CONF_DEPARTED_TRAIN_GRACE_PERIOD,
                    default=current_options.get(
                        CONF_DEPARTED_TRAIN_GRACE_PERIOD,
                        DEFAULT_DEPARTED_TRAIN_GRACE_PERIOD,
                    ),
                    description="Departed Train Grace Period (min)",
                ): vol.All(
                    vol.Coerce(int),
                    vol.Range(min=MIN_GRACE_PERIOD, max=MAX_GRACE_PERIOD),
                ),
                vol.Required(
                    CONF_NIGHT_UPDATES,
                    default=current_options.get(
                        CONF_NIGHT_UPDATES, DEFAULT_NIGHT_UPDATES
                    ),
                    description="Enable Night Updates",
                ): bool,
            }
        )

        return self.async_show_form(
            step_id="init",
            data_schema=data_schema,
            errors=errors,
        )
